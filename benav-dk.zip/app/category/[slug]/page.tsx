import Link from 'next/link'
import { prisma } from '@/lib/prisma'
import { notFound } from 'next/navigation'

export default async function CategoryPage({ params }: { params: { slug: string }}) {
  const cat = await prisma.category.findFirst({ where: { name: { equals: params.slug, mode: 'insensitive' }}})
  if (!cat) return notFound()
  const posts = await prisma.post.findMany({
    where: { published: true, categoryId: cat.id },
    orderBy: { publishedAt: 'desc' }
  })
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold capitalize">{cat.name}</h1>
      <div className="grid gap-6 sm:grid-cols-2">
        {posts.map(p => (
          <Link key={p.id} href={`/post/${p.slug}`} className="border rounded-2xl p-4 hover:shadow">
            <h2 className="text-xl font-semibold mt-1">{p.title}</h2>
          </Link>
        ))}
        {posts.length === 0 && <p>No posts for this category yet.</p>}
      </div>
    </div>
  )
}
