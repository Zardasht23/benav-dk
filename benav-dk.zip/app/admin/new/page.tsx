'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function NewPostPage() {
  const router = useRouter()
  const [title, setTitle] = useState('')
  const [slug, setSlug] = useState('')
  const [content, setContent] = useState('')
  const [category, setCategory] = useState('')
  const [published, setPublished] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, slug, content, category, published })
    })
    if (res.ok) router.push('/admin')
    else alert('Error creating post')
  }

  return (
    <form onSubmit={submit} className="max-w-2xl space-y-4">
      <h1 className="text-2xl font-bold">New Post</h1>
      <input className="w-full border rounded-xl p-2" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
      <input className="w-full border rounded-xl p-2" placeholder="Slug (unique-url)" value={slug} onChange={e=>setSlug(e.target.value)} />
      <input className="w-full border rounded-xl p-2" placeholder="Category (e.g., politics)" value={category} onChange={e=>setCategory(e.target.value)} />
      <textarea className="w-full border rounded-xl p-2 h-60" placeholder="HTML content for now (we can add a rich editor later)" value={content} onChange={e=>setContent(e.target.value)} />
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={published} onChange={e=>setPublished(e.target.checked)} />
        Published
      </label>
      <button className="rounded-xl px-4 py-2 border hover:bg-gray-50">Create</button>
    </form>
  )
}
