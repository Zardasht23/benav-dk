import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { auth } from 'next-auth'
import { redirect } from 'next/navigation'

export default async function AdminPage() {
  const session = await auth()
  // @ts-ignore
  if (!session || session.user.role !== 'ADMIN') redirect('/login')

  const posts = await prisma.post.findMany({
    orderBy: { createdAt: 'desc' },
    include: { category: true }
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Admin</h1>
        <Link href="/admin/new" className="rounded-xl px-4 py-2 border hover:bg-gray-50">New Post</Link>
      </div>
      <div className="divide-y">
        {posts.map(p => (
          <div key={p.id} className="py-3 flex items-center justify-between">
            <div>
              <div className="font-medium">{p.title}</div>
              <div className="text-sm text-gray-500">{p.category?.name || 'Uncategorized'}</div>
            </div>
            <div className="flex gap-3">
              <Link href={`/admin/edit/${p.id}`} className="text-sm underline">Edit</Link>
              <form action={`/api/posts/${p.id}`} method="post">
                <input type="hidden" name="_method" value="DELETE" />
                <button className="text-sm text-red-600 underline">Delete</button>
              </form>
            </div>
          </div>
        ))}
        {posts.length === 0 && <p>No posts yet.</p>}
      </div>
    </div>
  )
}
