import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'
import { auth } from 'next-auth'

export async function POST(req: Request, { params }: { params: { id: string }}) {
  const session = await auth()
  // @ts-ignore
  if (!session || session.user.role !== 'ADMIN') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const form = await req.formData()
  const method = form.get('_method')
  if (method === 'DELETE') {
    await prisma.post.delete({ where: { id: Number(params.id) }})
    return NextResponse.redirect(new URL('/admin', req.url))
  }
  return NextResponse.json({ ok: true })
}
