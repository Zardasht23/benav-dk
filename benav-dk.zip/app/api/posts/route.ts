import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'
import { auth } from 'next-auth'

export async function GET() {
  const posts = await prisma.post.findMany({ orderBy: { createdAt: 'desc' }})
  return NextResponse.json(posts)
}

export async function POST(req: Request) {
  const session = await auth()
  // @ts-ignore
  if (!session || session.user.role !== 'ADMIN') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { title, slug, content, category, published } = await req.json()
  const cat = category ? await prisma.category.upsert({
    where: { name: category },
    update: {},
    create: { name: category }
  }) : null

  const post = await prisma.post.create({
    data: {
      title, slug, content,
      categoryId: cat?.id,
      authorId: session.user.id as string,
      published: !!published,
      publishedAt: published ? new Date() : null
    }
  })
  return NextResponse.json(post)
}
