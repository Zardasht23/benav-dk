import Link from 'next/link'
import { prisma } from '@/lib/prisma'

export default async function HomePage() {
  const posts = await prisma.post.findMany({
    where: { published: true },
    orderBy: { publishedAt: 'desc' },
    take: 12,
    include: { category: true, author: true }
  })
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Latest Posts</h1>
      <div className="grid gap-6 sm:grid-cols-2">
        {posts.map(p => (
          <Link key={p.id} href={`/post/${p.slug}`} className="border rounded-2xl p-4 hover:shadow">
            <div className="text-xs uppercase tracking-wide text-gray-500">{p.category?.name}</div>
            <h2 className="text-xl font-semibold mt-1">{p.title}</h2>
            <div className="text-sm text-gray-500 mt-2">
              {p.publishedAt ? new Date(p.publishedAt).toLocaleDateString() : null}
            </div>
          </Link>
        ))}
        {posts.length === 0 && <p>No posts yet. Create one in the Admin panel.</p>}
      </div>
    </div>
  )
}
