import { prisma } from '@/lib/prisma'
import { notFound } from 'next/navigation'

export default async function PostPage({ params }: { params: { slug: string }}) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug },
    include: { author: true, category: true }
  })
  if (!post || !post.published) return notFound()
  return (
    <article className="prose max-w-none">
      <div className="text-xs uppercase tracking-wide text-gray-500">{post.category?.name}</div>
      <h1>{post.title}</h1>
      <div className="text-sm text-gray-500">
        {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : null} · by {post.author?.name || 'Unknown'}
      </div>
      {post.coverImage && <img src={post.coverImage} alt="" />}
      <div dangerouslySetInnerHTML={{ __html: post.content }} />
    </article>
  )
}
