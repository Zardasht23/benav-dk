import './globals.css'
import { ReactNode } from 'react'
import Link from 'next/link'

export const metadata = {
  title: process.env.NEXT_PUBLIC_SITE_NAME || 'Benav',
  description: 'A fast, modern blog on Next.js'
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-gray-900">
        <header className="border-b">
          <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
            <Link href="/" className="font-bold text-xl">{process.env.NEXT_PUBLIC_SITE_NAME || 'Benav'}</Link>
            <nav className="flex items-center gap-4 text-sm">
              <Link href="/category/politics">Politics</Link>
              <Link href="/category/literature">Literature</Link>
              <Link href="/admin">Admin</Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-4xl px-4 py-6">{children}</main>
        <footer className="border-t">
          <div className="mx-auto max-w-4xl px-4 py-6 text-sm text-gray-500">
            © {new Date().getFullYear()} {process.env.NEXT_PUBLIC_SITE_NAME || 'Benav'}
          </div>
        </footer>
      </body>
    </html>
  )
}
